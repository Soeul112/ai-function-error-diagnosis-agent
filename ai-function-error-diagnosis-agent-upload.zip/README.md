# AI Function Error Diagnosis Agent

面向高中函数错题的多轮诊断与个性化学习建议 Web 原型

An AI education web prototype for multi-turn diagnosis of high school function mistakes.

## 项目简介

本项目面向高一数学家教/课后辅导场景中的学生、老师和家长。学生的核心痛点不是“看不到答案”，而是做错后不知道自己错在条件遗漏、边界判断、概念混淆还是计算流程；老师则需要把错题复盘、变式练习和家长反馈整理成可持续的服务流程。项目通过结构化答案校验、多轮 AI 家教追问、错因归因、变式题巩固和家长/老师端报告，把一次错题变成可追踪的学习闭环。它是一个 AI 教育产品原型，不是单纯的聊天机器人。

## 功能概览

- 学生/题目选择：内置 3 个模拟学生、5 个高一函数模块、20 道自建题。
- 原题作答录入：支持输入定义域、值域、零点、奇偶性、单调性等答案形式。
- 结构化答案校验：对区间、不等式、零点集合、坐标点混淆、概念标签等进行归一化和等价判断。
- AI 多轮追问：答错后可启动 AI 家教诊断；未配置模型 Key 时自动降级为本地规则追问。
- 错因归因与证据展示：输出错误类型、诊断依据、薄弱知识点和复习建议。
- 再练一题：优先调用 LLM 生成相近难度练习，失败或缺 Key 时使用本地变式题模板。
- 家长报告：生成本次错因、下一步监督建议、变式迁移结果和可复制反馈文案。
- 老师工作台：汇总学生优先级、待办任务、高频错因、反馈草稿和最近变式练习。
- 作品集说明页：展示当前原型已验证能力、技术边界和下一步试点假设。

## 产品流程

```mermaid
flowchart LR
  A["学生选择题目并输入作答"] --> B["结构化答案校验"]
  B --> C{"答案是否等价"}
  C -->|正确| D["展示通过证据与复述建议"]
  C -->|错误| E["标记缺失条件/错因候选"]
  E --> F["启动 AI 家教追问"]
  F --> G{"LLM 是否可用"}
  G -->|可用| H["Gemini/Groq/OpenRouter 生成诊断 JSON"]
  G -->|不可用| I["本地规则降级生成追问"]
  H --> J["学生回应追问"]
  I --> J
  J --> K["提示强度递增，必要时给出完整解析"]
  K --> L["保存诊断报告"]
  L --> M["生成再练一题"]
  M --> N["家长报告与老师工作台同步更新"]
```

## 技术架构

```mermaid
flowchart TB
  subgraph Frontend["React + Vite 前端"]
    UI["学习看板 / 诊断 Copilot / 家长报告 / 老师工作台"]
    State["App 状态与页面交互"]
  end

  subgraph Backend["Node.js + Express 后端"]
    API["REST API 路由"]
    Service["services.js 业务编排"]
    Checker["answerAnalysis.js 结构化答案校验"]
    Prompt["prompts.js Prompt 与 JSON Schema"]
    LLM["可选 LLM Provider: Gemini / Groq / OpenRouter"]
    Fallback["本地规则降级"]
  end

  DB["node:sqlite 本地 SQLite\n运行时生成 data/app.db"]

  UI --> State --> API
  API --> Service
  Service --> Checker
  Service --> Prompt
  Prompt --> LLM
  LLM --> Service
  LLM -. "缺少 Key / 超时 / JSON 失败" .-> Fallback
  Fallback --> Service
  Service --> DB
  Service --> UI
```

真实技术栈：

- 前端：React 18 + Vite 6 + lucide-react。
- 后端：Node.js 24 + Express 4 + CORS + dotenv。
- 数据：Node 24 内置 `node:sqlite`，本地生成 `data/app.db`；初始数据来自 `server/seedData.js`。
- AI 接入：`server/ai/llmProvider.js` 封装 Gemini、Groq、OpenRouter；无 API Key 或模型异常时走本地规则降级。
- 当前没有外部数据库、用户登录系统或线上部署配置。

## 项目截图

截图均来自本地真实运行页面，保存于 `docs/screenshots/`。

![学习看板](docs/screenshots/01-dashboard.png)
学习看板展示学生画像、诊断证据、知识点掌握和题库模块。

![作答与结构化校验](docs/screenshots/02-answer-check.png)
学生输入常见错误答案后，系统先做结构化等价校验并展示缺失条件。

![AI 多轮追问](docs/screenshots/03-ai-followup.png)
未配置模型 Key 时，页面明确显示本地规则降级，并继续给出家教式追问。

![诊断结果与再练一题](docs/screenshots/04-final-practice.png)
连续追问后给出完整诊断、证据、复习建议，并生成同知识点练习。

![家长报告](docs/screenshots/05-parent-report.png)
家长视角展示本次错因、监督建议、薄弱知识点和可复制反馈文案。

![老师工作台](docs/screenshots/06-teacher-workspace.png)
老师端汇总待办任务、学生跟进卡、高频错因、反馈草稿和变式练习记录。

## 本地启动方式

### 环境要求

- Node.js 24.x。项目使用 Node 24 内置 `node:sqlite`，低版本 Node 可能无法启动数据库模块。
- npm 11.x 或兼容版本。

### 启动步骤

```bash
git clone https://github.com/<your-github-name>/ai-function-error-diagnosis-agent.git
cd ai-function-error-diagnosis-agent
npm install
```

复制环境变量示例：

```bash
cp .env.example .env
```

Windows PowerShell 可使用：

```powershell
Copy-Item .env.example .env
```

启动前后端开发服务：

```bash
npm run dev
```

打开浏览器：

```text
http://127.0.0.1:5173/
```

后端 API 默认地址：

```text
http://127.0.0.1:5174/
```

### 可选 LLM 配置

不配置 API Key 也可以完整演示页面与本地规则诊断。若要接入真实模型，在 `.env` 中配置其中一种 Provider：

```text
LLM_PROVIDER=gemini
GEMINI_API_KEY=your_gemini_api_key_here
```

也可以使用 `groq` 或 `openrouter`，对应变量见 `.env.example`。

### 验证命令

```bash
npm run test:api
npm run build
```

### 常见问题

- `node:sqlite` 相关报错：请确认 Node.js 版本为 24.x。
- PowerShell 提示 `npm.ps1 cannot be loaded`：可改用 `npm.cmd run dev`、`npm.cmd run build`、`npm.cmd run test:api`。
- `5173` 或 `5174` 端口被占用：关闭已有本地服务，或按 Vite 输出的备用端口访问；后端默认端口可通过 `.env` 中的 `PORT` 调整。
- AI 显示“本地规则降级”：通常是未配置 API Key、请求超时或模型 JSON 返回不稳定；这属于当前原型的预期兜底路径。

## 项目亮点

- 教育场景拆解清晰：围绕高一函数错题复盘，不只给答案，而是追踪“为什么错”和“换题还会不会”。
- 规则校验与 AI 诊断结合：先用结构化校验给出可解释证据，再把题目、学生答案、历史记录和错因候选传入 AI/规则诊断链路。
- 多轮 Agent 流程可控：Prompt 要求一次只推进一个关键问题，连续多轮不会时逐步提高提示强度并给出完整解析。
- 输出结构化，便于产品化：诊断结果、错因、复习建议、变式题和家长反馈都以可展示、可保存的数据结构流转。
- 有基本验收脚本：`server/smoke-test.js` 覆盖题库读取、作答保存、诊断报告、变式作答、家长报告和老师工作台接口。

## 项目结构

```text
.
├── index.html
├── package.json
├── vite.config.js
├── src/
│   ├── main.jsx              # React 页面、状态流和主要交互
│   └── styles.css            # 页面样式
├── server/
│   ├── index.js              # Express 服务启动入口
│   ├── app.js                # API 路由与静态资源托管
│   ├── services.js           # 诊断、变式、报告、老师端业务编排
│   ├── db.js                 # node:sqlite 表结构与数据读写
│   ├── seedData.js           # 模拟学生、题库、错因和变式模板
│   ├── answerAnalysis.js     # 结构化答案归一化与等价校验
│   ├── smoke-test.js         # API 冒烟测试
│   └── ai/
│       ├── llmProvider.js    # LLM Provider 选择、JSON 解析与兜底
│       ├── prompts.js        # 家教诊断 Prompt 与 JSON Schema
│       └── providers/        # Gemini / Groq / OpenRouter HTTP 调用
├── docs/
│   ├── architecture.md
│   ├── product-flow.md
│   ├── demo.md
│   └── screenshots/
├── .env.example
├── .gitignore
└── LICENSE
```

## 简历描述建议

- 设计并实现面向高一函数错题的 AI 教育 Web 原型，跑通学生作答、结构化校验、AI 多轮追问、错因归因、变式练习、家长报告和老师工作台闭环。
- 基于 React + Node.js + Express + node:sqlite 搭建本地可运行系统，自建 3 类学生画像、5 个函数模块、20 道题和错因标签体系。
- 封装 Gemini/Groq/OpenRouter 可替换 LLM 服务层，并实现缺 Key、超时、JSON 解析失败时的本地规则降级，保证演示链路稳定可用。

